function validate(){
	
	var userName=document.getElementById("user").value;
	var userpasswd=document.getElementById("psswd").value;
	if(userName==""||userName==null){
		 alert("name should not be empty");
		 return false;
	}else if(userpasswd==""||userpasswd==null){
		 alert("please enter your password");
			return false;
	}else if(!isNaN(userName)){
		 alert("name should not consist of digits");
		 return false;
	 }
	return true;
}